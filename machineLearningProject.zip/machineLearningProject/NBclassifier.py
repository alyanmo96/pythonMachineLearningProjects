import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

data = np.genfromtxt("spam.csv", delimiter=",", dtype=type(""), skip_header=1, usecols=np.arange(0, 2))

# --------------------------------------------------------------------------------------------------------------------
# [1.0] feature extraction - bag of words -

# removing quotation marks
statements = []
for i in range(len(data)):
    data[i][1] = data[i][1][1:len(data[i][1]) - 1]
    statements.append(data[i][1])

# vectorizing data
vectorizer = CountVectorizer()

X = vectorizer.fit_transform(statements).toarray()
# X[statement_index][feature_index] = the number of occurrences of the feature(word) in the statement[FREQUENCY]

features = vectorizer.get_feature_names()  # array of all the features(words)

train_statements = []  # list of train statements (string)
train_X = []  # list of train feature vectors
train_Y = []  # list of train Y (0 or 1 -> ham or spam)

test_statements = []  # list of test statements (string)
test_X = []  # list of test feature vectors
test_Y = []  # list of test Y (0 or 1 -> ham or spam)

for i in range(X.shape[0]):
    if i < 0.70 * X.shape[0]:
        train_statements.append(statements[i])
        train_X.append(X[i])
        if data[i][0] == 'ham':
            train_Y.append(0)
        else:
            train_Y.append(1)
    else:
        test_statements.append(statements[i])
        test_X.append(X[i])
        if data[i][0] == 'ham':
            test_Y.append(0)
        else:
            test_Y.append(1)
print('train set length:', len(train_statements))
print('test set length:', len(test_statements))
print('feature vector length:', len(features))
# --------------------------------------------------------------------------------------------------------------------

# [2.0] creating the NB model
model = MultinomialNB()
model.fit(train_X, train_Y)
predictions = model.predict(test_X)
probabilities = model.predict_proba(test_X)
# --------------------------------------------------------------------------------------------------------------------

# [3.0] metrics
print()
print('--Metrics for MultinomialNB:--')
accuracy = accuracy_score(test_Y, predictions)
precision, recall, fscore, none = precision_recall_fscore_support(test_Y, predictions, average='binary')
print('accuracy:', accuracy)
print('precision:', precision)
print('recall:', recall)
print('fscore:', fscore)
# --------------------------------------------------------------------------------------------------------------------
