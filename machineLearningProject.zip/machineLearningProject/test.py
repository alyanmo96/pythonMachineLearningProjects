import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVR
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import precision_recall_fscore_support, accuracy_score, roc_curve
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

data = np.genfromtxt("spam.csv", delimiter=",", dtype=type(""), skip_header=1, usecols=np.arange(0, 2))

# --------------------------------------------------------------------------------------------------------------------

# [1.0] feature extraction - bag of words -
# removing quotation marks
statements = []
for i in range(len(data)):
    data[i][1] = data[i][1][1:len(data[i][1]) - 1]
    statements.append(data[i][1])

# vectorizing data
vectorizer = CountVectorizer()

X = vectorizer.fit_transform(statements).toarray()
# X[statement_index][feature_index] = the number of occurrences of the feature(word) in the statement[FREQUENCY]

features = vectorizer.get_feature_names()  # array of all the features(words)

# splitting data into 70% train and 30% test
train_statements = []  # list of train statements (string)
train_X = []  # list of train feature vectors
train_Y = []  # list of train Y (0 or 1 -> ham or spam)

test_statements = []  # list of test statements (string)
test_X = []  # list of test feature vectors
test_Y = []  # list of test Y (0 or 1 -> ham or spam)

for i in range(X.shape[0]):
    if i < 0.70 * X.shape[0]:
        train_statements.append(statements[i])
        train_X.append(X[i])
        if data[i][0] == 'ham':
            train_Y.append(0)
        else:
            train_Y.append(1)
    else:
        test_statements.append(statements[i])
        test_X.append(X[i])
        if data[i][0] == 'ham':
            test_Y.append(0)
        else:
            test_Y.append(1)
# --------------------------------------------------------------------------------------------------------------------

# [2.0] NB classifier  - overfitting -
print('[PART 1] -- NB classifier  -- overfitting --')
num_of_samples = [10, 100, 500, 1000, 1500, 2000, 2500, 3000, 3902]
train_errors = []
test_errors = []
print('\nRunning NB classifier on different number of samples..')
for i in range(len(num_of_samples)):
    smodel = MultinomialNB()
    smodel.fit(train_X[0:num_of_samples[i]], train_Y[0:num_of_samples[i]])

    train_error = 1 - smodel.score(train_X[0:num_of_samples[i]], train_Y[0:num_of_samples[i]])
    test_error = 1 - smodel.score(test_X[0:num_of_samples[i]], test_Y[0:num_of_samples[i]])

    train_errors.append(train_error)
    test_errors.append(test_error)
print('Done\n')
plt.plot(num_of_samples, train_errors, 'r')
plt.plot(num_of_samples, test_errors, 'g')

plt.xlabel('# of samples')
plt.ylabel('error')

red_patch = mpatches.Patch(color='red', label='errors on train set')
green_patch = mpatches.Patch(color='green', label='errors on test set')
plt.legend(handles=[red_patch, green_patch])

print('Showing graph to detect overfitting')
print('Close the figure to continue to the next part [SVM model]')
plt.show()
print('-- END O PART 1 -- ')
print()
# --------------------------------------------------------------------------------------------------------------------
print('[PART 2] -- SVM model  -- optimum kernel and threshold --')
# [3.0] SVM - optimum model with optimum threshold -

# [3.1] creating the SVM models with different kernels
svm_rbf_model = SVR(gamma='auto', kernel='rbf')
svm_linear_model = SVR(gamma='auto', kernel='linear')
svm_poly_model = SVR(gamma='auto', kernel='poly')
svm_sigmoid_model = SVR(gamma='auto', kernel='sigmoid')

print('Training SVM models.. (allow up to 5 minutes)')
svm_rbf_model.fit(train_X, train_Y)
svm_rbf_preds = svm_rbf_model.predict(test_X)

svm_linear_model.fit(train_X, train_Y)
svm_linear_preds = svm_linear_model.predict(test_X)

svm_poly_model.fit(train_X, train_Y)
svm_poly_preds = svm_poly_model.predict(test_X)

svm_sigmoid_model.fit(train_X, train_Y)
svm_sigmoid_preds = svm_sigmoid_model.predict(test_X)
print('done training SVM models')

# [3.2] finding optimum threshold for each SVM kernel
for i in range(4):
    predictions = None
    kernel_name = None
    plot_id = 221
    if i == 0:
        predictions = svm_rbf_preds
        kernel_name = 'RBF'
        plot_id = 221
    elif i == 1:
        predictions = svm_linear_preds
        kernel_name = 'Linear'
        plot_id = 222
    elif i == 2:
        predictions = svm_poly_preds
        kernel_name = 'Polynomial'
        plot_id = 223
    elif i == 3:
        predictions = svm_sigmoid_preds
        kernel_name = 'Sigmoid'
        plot_id = 224

    fpr, tpr, thresholds = roc_curve(test_Y, predictions)
    optimum_i = 0
    optimum_threshold = thresholds[0]
    max_fscore = 0
    for i in range(len(thresholds)):
        t = thresholds[i]
        preds_t = []
        for p in range(len(predictions)):
            if predictions[p] < t:
                preds_t.append(0)
            else:
                preds_t.append(1)
        precision_t, recall_t, fscore_t, none = precision_recall_fscore_support(test_Y, preds_t, average='binary')
        if fscore_t > max_fscore:
            max_fscore = fscore_t
            optimum_threshold = t
            optimum_i = i

    # metrics
    for i in range(len(predictions)):
        if predictions[i] < optimum_threshold:
            predictions[i] = 0
        else:
            predictions[i] = 1
    print()
    print('---Metrics for SVM kernel:', kernel_name, '---')
    print('optimum threshold:', optimum_threshold)
    accuracy = accuracy_score(test_Y, predictions)
    precision, recall, fscore, none = precision_recall_fscore_support(test_Y, predictions, average='binary')
    print('accuracy:', accuracy)
    print('precision:', precision)
    print('recall:', recall)
    print('fscore:', fscore)
    print('-----')

    # plotting ROC curve highlighting the optimum threshold
    ax2 = plt.subplot(plot_id)
    ax2.plot(fpr[optimum_i], tpr[optimum_i], marker='o', label='optimum threshold:' + '%.4f' % optimum_threshold)
    box = ax2.get_position()
    ax2.set_position([box.x0, box.y0 + box.height * 0.4,
                      box.width, box.height * 0.6])
    ax2.legend(loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2, shadow=True, fancybox=True,
               title='SVM ' + kernel_name + ' ROC curve').get_frame().set_alpha(0.5)
    plt.plot(fpr, tpr)
    plt.xlabel('FPR')
    plt.ylabel('TPR')
print('SVM: Showing ROC curves for different kernels, metrics are listed above ^')
print('Close the figure to exit the program')
plt.show()
print('-- END OF PART 2 -- ')
# --------------------------------------------------------------------------------------------------------------------
